"""
Liquid Zimbabwe 4G Network Optimizer - Configuration Agent
Purpose: Recommend parameter changes using few-shot learning
Created: 2025-10-30
"""

from typing import Dict, Any
from langgraph.prebuilt import create_react_agent
from langchain_core.prompts import PromptTemplate
import sys
import os
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.huawei_tools import query_huawei_parameter, validate_parameter_range
from tools.sql_tools import execute_historical_sql
from tools.dummy_responses import get_config_recommendation_dummy, DUMMY_CONFIG_RECOMMENDATIONS
from prompts.system_prompts import CONFIGURATION_AGENT_PROMPT
from prompts.few_shot_examples import format_few_shot_examples
from utils.timeout_handler import safe_llm_call, TimeoutError, CONFIG_TIMEOUT
from utils.llm_factory import get_llm_client

logger = logging.getLogger(__name__)


def config_agent(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Configuration Agent - Recommends parameter changes using few-shot learning.

    2-TIER FALLBACK MECHANISM:
    Tier 1: LLM agent with Huawei API tools (with 45s timeout)
    Tier 2: Rule-based recommendations from dummy data (always succeeds)
    """
    logger.info(f"🤖 CONFIGURATION AGENT - Starting parameter recommendation")

    # Extract parameters
    site_name = state.get("site_name", "Unknown")
    primary_kpi_issue = state.get("primary_kpi_issue", "unknown")
    kpi_analytics_output = state.get('kpi_analytics_output', '')

    logger.info(f"📝 Task: Recommendations for {site_name}, Issue: {primary_kpi_issue}")

    # ==========================================================================
    # TIER 1: Try LLM Agent with Tools (Primary)
    # ==========================================================================
    def try_llm_agent():
        """Attempt LLM-based configuration recommendations."""
        logger.info("🔄 TIER 1: Attempting LLM agent configuration...")

        # Use LLM factory to get client (supports OpenAI, NVIDIA, etc.)
        llm = get_llm_client()

        tools = [query_huawei_parameter, validate_parameter_range, execute_historical_sql]

        # Get relevant few-shot examples
        few_shot_examples = format_few_shot_examples(primary_kpi_issue, top_n=2)

        task = f"""
Generate parameter recommendations for site: {site_name}
Primary KPI Issue: {primary_kpi_issue}
KPI Analytics: {kpi_analytics_output}

STEPS:
1. Query current parameter values using tools
2. Review few-shot examples below for similar cases
3. Match KPI issue to optimization rules
4. Recommend specific parameter changes with exact values
5. Validate proposed values using validate_parameter_range

{few_shot_examples}

CRITICAL: After using tools, YOU MUST write complete detailed recommendations following the FINAL ANSWER FORMAT in the system prompt. Include:
- PRIMARY ISSUE with context
- PRIMARY PARAMETER with exact current/recommended values (e.g., MS1000_T310 → MS2000_T310)
- Exact change with unit (+1000 ms)
- Detailed reasoning with projections (91.0% → 94.0%)
- Expected KPI improvements with specific numbers
- Technical effects

DO NOT stop after tool execution - provide the full detailed textual recommendations!
"""

        # Build system prompt with task
        system_prompt = CONFIGURATION_AGENT_PROMPT + "\n\n" + task + "\n\nUSE TOOLS TO COMPLETE THIS TASK."

        # Create ReAct agent (LangGraph version)
        agent = create_react_agent(llm, tools, prompt=system_prompt)

        # Execute agent
        result = agent.invoke({"messages": [{"role": "user", "content": task}]})

        # DEBUG: Log all messages
        logger.info(f"🔍 DEBUG: Total messages returned: {len(result.get('messages', []))}")
        for i, msg in enumerate(result.get("messages", [])):
            msg_type = getattr(msg, 'type', '') or getattr(msg, '__class__', '').__name__.lower()
            content_preview = str(msg.content)[:200] if hasattr(msg, 'content') else "No content"
            logger.info(f"🔍 Message {i}: Type={msg_type}, Content={content_preview}...")

        # Extract output from AI messages only (not user/human, not tool calls)
        ai_responses = []
        if "messages" in result and len(result["messages"]) > 0:
            for msg in result["messages"]:
                # Only get AI messages (check message type)
                msg_type = getattr(msg, 'type', '') or getattr(msg, '__class__', '').__name__.lower()
                if 'ai' in str(msg_type).lower() and hasattr(msg, 'content') and msg.content:
                    content = str(msg.content)
                    # Skip tool calls and task echoes
                    if ('<function' not in content and 
                        'YOUR TASK:' not in content and
                        len(content) > 100):
                        ai_responses.append(content)
                        logger.info(f"✅ Captured AI response: {len(content)} chars")
        
        # If no final text found, force LLM to generate it
        if not ai_responses:
            logger.info("⚠️ No final text found - requesting explicit final answer from LLM...")
            # Add follow-up message to existing conversation
            followup_prompt = """
Based on the tool results above, now provide your FINAL ANSWER in the exact detailed format specified in the system prompt.

Include:
- ━━━ visual separators
- All sections (ISSUE IDENTIFIED, RECOMMENDED CHANGES, RISK ASSESSMENT, EXPECTED IMPACT)
- Specific parameter values with enums (e.g., MS1000_T310 → MS2000_T310)
- Quantified changes (±X ms, ±Y%)
- Projections (Current% → Target% (+Xpp))
- Risk scores with emoji indicators (🟢 🟡 🔴)
- Detailed technical justifications

Write your complete detailed analysis NOW:
"""
            # Continue conversation with follow-up
            messages = result.get("messages", [])
            messages.append({"role": "user", "content": followup_prompt})
            result = agent.invoke({"messages": messages})
            
            logger.info(f"🔍 Follow-up returned {len(result.get('messages', []))} total messages")
            
            # Extract AI response from follow-up
            for msg in reversed(result.get("messages", [])):
                msg_type = str(getattr(msg, 'type', '') or getattr(msg, '__class__', '').__name__).lower()
                if 'ai' in msg_type and hasattr(msg, 'content'):
                    content = str(msg.content)
                    if '<function' not in content and len(content) > 100:
                        ai_responses.append(content)
                        logger.info(f"✅ Captured follow-up AI response: {len(content)} chars")
                        break
        
        # Combine all AI responses
        if ai_responses:
            output = "\n\n".join(ai_responses)
        else:
            # Last resort fallback
            logger.warning("⚠️ Still no valid AI response after follow-up - using last message")
            output = str(result.get("messages", [])[-1].content) if result.get("messages") else str(result)

        # Detect failures or incomplete output in LLM response
        if "ERROR" in output.upper():
            raise Exception(f"LLM generated error output: {output[:200]}")
        
        # Check if output is just tool calls without actual detailed recommendations
        has_tool_calls_only = ('<function' in output and output.count('\n') < 20)
        has_detailed_sections = ('PRIMARY PARAMETER' in output.upper() or 
                                'RECOMMENDED CHANGES' in output.upper() or
                                'ISSUE IDENTIFIED' in output.upper())
        
        if has_tool_calls_only or not has_detailed_sections:
            logger.warning(f"⚠️  LLM output incomplete (tool calls only, no detailed recommendations)")
            raise Exception(f"LLM output incomplete - falling back to detailed Tier 2 responses")

        return output

    # ==========================================================================
    # TIER 2: Rule-Based Recommendations (Fallback - Always Succeeds)
    # ==========================================================================
    def use_rule_based_config():
        """Fallback: Use rule-based configuration recommendations from dummy data."""
        logger.info("🔄 TIER 2: Using rule-based configuration recommendations...")

        # Get dummy recommendation based on primary KPI issue
        output = get_config_recommendation_dummy(primary_kpi_issue)

        logger.info(f"✅ Rule-based recommendations generated for issue: {primary_kpi_issue}")

        return output

    # ==========================================================================
    # EXECUTION LOGIC: Try Tier 1 → Tier 2
    # ==========================================================================
    output = None

    try:
        # TIER 1: Try LLM with timeout
        output = safe_llm_call(
            llm_function=try_llm_agent,
            fallback_function=lambda: None,  # Return None to trigger Tier 2
            timeout_seconds=CONFIG_TIMEOUT,
            operation_name="Configuration Agent (LLM)"
        )

        if output is not None:
            logger.info("✅ TIER 1 SUCCESS: LLM configuration recommendations complete")
        else:
            raise Exception("LLM returned None - triggering fallback")

    except Exception as e:
        logger.warning(f"⚠️  TIER 1 failed: {e}")

        # TIER 2: Use rule-based fallback
        output = use_rule_based_config()
        logger.info("✅ TIER 2 SUCCESS: Rule-based configuration complete")

    # ==========================================================================
    # UPDATE STATE
    # ==========================================================================
    state["config_output"] = output
    state["agent_outputs"] = state.get("agent_outputs", {})
    state["agent_outputs"]["configuration"] = output

    logger.info(f"💬 CONFIGURATION OUTPUT:\n{output[:300]}...")

    return state
