"""
Liquid Zimbabwe 4G Network Optimizer - Validation Agent
Purpose: Validate parameter changes and assess safety
Created: 2025-10-30
"""

from typing import Dict, Any
from utils.llm_factory import get_llm_client
from langgraph.prebuilt import create_react_agent
from langchain_core.prompts import PromptTemplate
import sys
import os
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.huawei_tools import validate_parameter_range
from tools.validation_tools import assess_risk_score, validate_optimization_safety
from tools.sql_tools import execute_historical_sql
from tools.dummy_responses import get_validation_result_dummy, DUMMY_VALIDATION_RESULTS
from prompts.system_prompts import VALIDATION_AGENT_PROMPT
from utils.timeout_handler import safe_llm_call, TimeoutError, VALIDATION_TIMEOUT

logger = logging.getLogger(__name__)


def validation_agent(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validation Agent - Validates safety of proposed parameter changes.

    2-TIER FALLBACK MECHANISM:
    Tier 1: LLM agent with validation tools (with 30s timeout)
    Tier 2: Rule-based validation from dummy data (always APPROVED for demo)
    """
    logger.info(f"🤖 VALIDATION AGENT - Starting safety validation")

    # Extract parameters
    site_name = state.get("site_name", "Unknown")
    config_output = state.get('config_output', '')
    primary_kpi_issue = state.get('primary_kpi_issue', 'unknown')

    logger.info(f"📝 Task: Validating recommendations for {site_name}")

    # ==========================================================================
    # TIER 1: Try LLM Agent with Tools (Primary)
    # ==========================================================================
    def try_llm_agent():
        """Attempt LLM-based validation."""
        logger.info("🔄 TIER 1: Attempting LLM agent validation...")

        # Initialize LLM using factory (supports OpenAI, NVIDIA, etc.)
        # Lower temperature for safety-critical decisions
        llm = get_llm_client(temperature=0.3)

        tools = [validate_parameter_range, assess_risk_score, validate_optimization_safety, execute_historical_sql]

        task = f"""
Validate parameter recommendations for site: {site_name}
Parameter Recommendations: {config_output}

STEPS:
1. Extract all parameter changes from recommendations
2. For EACH parameter:
   - Validate value range using validate_parameter_range
   - Assess risk score using assess_risk_score  
3. Validate combined safety using validate_optimization_safety
4. Determine decision: APPROVED (risk ≤5), REVIEW (5<risk≤7), or REJECTED (risk>7)

CRITICAL: After using tools, YOU MUST write complete detailed validation following the FINAL ANSWER FORMAT in the system prompt. Include:
- DECISION and RISK SCORE
- Specific risk factors with quantified impacts (e.g., Ping-Pong HO: 2.5%→4.1%)
- Mitigation strategies with details
- Safety checks for each parameter
- Expected impact with specific KPI projections
- Technical effects with trade-offs
- Rollback strategy with exact steps

DO NOT stop after tool execution - provide the full detailed textual validation!
"""

        # Build system prompt with task
        system_prompt = VALIDATION_AGENT_PROMPT + "\n\n" + task + "\n\nUSE TOOLS TO COMPLETE THIS TASK."

        # Create ReAct agent (LangGraph version)
        agent = create_react_agent(llm, tools, prompt=system_prompt)

        # Execute agent
        result = agent.invoke({"messages": [{"role": "user", "content": task}]})

        # DEBUG: Log all messages
        logger.info(f"🔍 DEBUG: Total messages returned: {len(result.get('messages', []))}")
        for i, msg in enumerate(result.get("messages", [])):
            msg_type = getattr(msg, 'type', '') or getattr(msg, '__class__', '').__name__.lower()
            content_preview = str(msg.content)[:200] if hasattr(msg, 'content') else "No content"
            logger.info(f"🔍 Message {i}: Type={msg_type}, Content={content_preview}...")

        # Extract output from AI messages only (not user/human, not tool calls)
        ai_responses = []
        if "messages" in result and len(result["messages"]) > 0:
            for msg in result["messages"]:
                # Only get AI messages (check message type)
                msg_type = getattr(msg, 'type', '') or getattr(msg, '__class__', '').__name__.lower()
                if 'ai' in str(msg_type).lower() and hasattr(msg, 'content') and msg.content:
                    content = str(msg.content)
                    # Skip tool calls and task echoes
                    if ('<function' not in content and 
                        'YOUR TASK:' not in content and
                        len(content) > 100):
                        ai_responses.append(content)
                        logger.info(f"✅ Captured AI response: {len(content)} chars")
        
        # If no final text found, force LLM to generate it
        if not ai_responses:
            logger.info("⚠️ No final text found - requesting explicit final answer from LLM...")
            # Add follow-up message to existing conversation
            followup_prompt = """
Based on the tool results above, now provide your FINAL ANSWER in the exact detailed format specified in the system prompt.

Include:
- ━━━ visual separators
- All sections (PARAMETER-BY-PARAMETER SAFETY ANALYSIS, MULTI-PARAMETER CONFLICT ANALYSIS, etc.)
- Specific parameter values with units
- ✅ Range checks, 📊 Historical analysis, ⚠️ Side effects
- Risk scores with emoji indicators (🟢 🟡 🔴)
- Detailed justifications

Write your complete detailed validation analysis NOW:
"""
            # Continue conversation with follow-up
            messages = result.get("messages", [])
            messages.append({"role": "user", "content": followup_prompt})
            result = agent.invoke({"messages": messages})
            
            logger.info(f"🔍 Follow-up returned {len(result.get('messages', []))} total messages")
            
            # Extract AI response from follow-up
            for msg in reversed(result.get("messages", [])):
                msg_type = str(getattr(msg, 'type', '') or getattr(msg, '__class__', '').__name__).lower()
                if 'ai' in msg_type and hasattr(msg, 'content'):
                    content = str(msg.content)
                    if '<function' not in content and len(content) > 100:
                        ai_responses.append(content)
                        logger.info(f"✅ Captured follow-up AI response: {len(content)} chars")
                        break
        
        # Combine all AI responses
        if ai_responses:
            output = "\n\n".join(ai_responses)
        else:
            # Last resort fallback
            logger.warning("⚠️ Still no valid AI response after follow-up - using last message")
            output = str(result.get("messages", [])[-1].content) if result.get("messages") else str(result)

        # Detect failures in LLM output
        if "ERROR" in output.upper():
            raise Exception(f"LLM generated error output: {output[:200]}")

        return output

    # ==========================================================================
    # TIER 2: Rule-Based Validation (Fallback - Always APPROVED for Demo)
    # ==========================================================================
    def use_rule_based_validation():
        """Fallback: Use rule-based validation from dummy data (always approves for demo)."""
        logger.info("🔄 TIER 2: Using rule-based validation (demo mode)...")

        # For demo, always use APPROVED_LOW_RISK validation
        # In production, you could analyze config_output to determine risk level
        output = get_validation_result_dummy("LOW")

        logger.info(f"✅ Rule-based validation complete - Status: APPROVED (demo mode)")

        return output

    # ==========================================================================
    # EXECUTION LOGIC: Try Tier 1 → Tier 2
    # ==========================================================================
    output = None
    validation_status = "PENDING"

    try:
        # TIER 1: Try LLM with timeout
        output = safe_llm_call(
            llm_function=try_llm_agent,
            fallback_function=lambda: None,  # Return None to trigger Tier 2
            timeout_seconds=VALIDATION_TIMEOUT,
            operation_name="Validation Agent (LLM)"
        )

        if output is not None:
            logger.info("✅ TIER 1 SUCCESS: LLM validation complete")

            # Determine approval status from LLM output
            output_upper = output.upper()
            if "APPROVED" in output_upper:
                validation_status = "APPROVED"
            elif "REJECTED" in output_upper:
                validation_status = "REJECTED"
            else:
                validation_status = "REVIEW"
        else:
            raise Exception("LLM returned None - triggering fallback")

    except Exception as e:
        logger.warning(f"⚠️  TIER 1 failed: {e}")

        # TIER 2: Use rule-based fallback
        output = use_rule_based_validation()
        validation_status = "APPROVED"  # Demo mode always approves
        logger.info("✅ TIER 2 SUCCESS: Rule-based validation complete")

    # ==========================================================================
    # UPDATE STATE
    # ==========================================================================
    state["validation_output"] = output
    state["validation_status"] = validation_status
    state["agent_outputs"] = state.get("agent_outputs", {})
    state["agent_outputs"]["validation"] = output

    logger.info(f"💬 VALIDATION OUTPUT:\n{output[:300]}...")
    logger.info(f"✅ VALIDATION STATUS: {validation_status}")

    return state
